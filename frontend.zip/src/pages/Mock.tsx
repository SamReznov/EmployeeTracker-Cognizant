import React from 'react'
import { Pagination } from "@mui/material";
const Mock = () => {
  return (
    <div>
        <Pagination/>
    </div>
  )
}

export default Mock