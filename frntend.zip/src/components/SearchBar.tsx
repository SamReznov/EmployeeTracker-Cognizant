import React from 'react'
import { MDBCol, MDBBtn } from "mdb-react-ui-kit";

const SearchBar = () => {
  return (
    <div>
        
    </div>
  )
}

export default SearchBar